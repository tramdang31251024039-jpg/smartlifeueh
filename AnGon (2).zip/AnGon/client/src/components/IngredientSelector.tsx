import { useState, useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ChefHat, RefreshCw, Camera, X } from 'lucide-react';

const INGREDIENTS = [
  { id: 'egg', name: 'Trứng', category: 'protein' },
  { id: 'meat', name: 'Thịt', category: 'protein' },
  { id: 'fish', name: 'Cá', category: 'protein' },
  { id: 'tofu', name: 'Đậu hũ', category: 'protein' },
  { id: 'vegetables', name: 'Rau', category: 'vegetable' },
  { id: 'tomato', name: 'Cà chua', category: 'vegetable' },
  { id: 'cabbage', name: 'Bắp cải', category: 'vegetable' },
  { id: 'carrot', name: 'Cà rốt', category: 'vegetable' },
  { id: 'noodles', name: 'Mì gói', category: 'grain' },
  { id: 'rice', name: 'Gạo', category: 'grain' },
  { id: 'potato', name: 'Khoai tây', category: 'grain' },
  { id: 'onion', name: 'Hành tây', category: 'vegetable' },
];

const RECIPES = [
  {
    id: 1,
    name: 'Trứng chiên',
    ingredients: ['egg'],
    instructions: '1. Đập trứng vào bát\n2. Cho chút muối, đánh đều\n3. Làm nóng chảo, cho dầu\n4. Đổ trứng vào chiên vàng hai mặt',
  },
  {
    id: 2,
    name: 'Trứng ốp la',
    ingredients: ['egg'],
    instructions: '1. Làm nóng chảo, cho dầu\n2. Đập trứng vào chảo\n3. Rắc muối tiêu\n4. Chiên đến khi lòng đỏ chín tới',
  },
  {
    id: 3,
    name: 'Rau xào',
    ingredients: ['vegetables'],
    instructions: '1. Rửa rau, để ráo nước\n2. Làm nóng chảo, phi tỏi\n3. Cho rau vào xào nhanh tay\n4. Nêm nếm vừa ăn',
  },
  {
    id: 4,
    name: 'Canh rau',
    ingredients: ['vegetables'],
    instructions: '1. Rửa rau sạch\n2. Đun nước sôi\n3. Cho rau vào nấu\n4. Nêm gia vị cho vừa ăn',
  },
  {
    id: 5,
    name: 'Đậu hũ chiên',
    ingredients: ['tofu'],
    instructions: '1. Cắt đậu hũ miếng vừa\n2. Làm nóng dầu\n3. Chiên đậu hũ vàng đều\n4. Chấm nước mắm ớt',
  },
  {
    id: 6,
    name: 'Cá chiên',
    ingredients: ['fish'],
    instructions: '1. Ướp cá với muối, tiêu\n2. Để 10 phút cho thấm\n3. Chiên vàng hai mặt\n4. Rắc hành lá',
  },
  {
    id: 7,
    name: 'Bắp cải xào',
    ingredients: ['cabbage'],
    instructions: '1. Thái bắp cải vừa ăn\n2. Phi tỏi cho thơm\n3. Xào bắp cải nhanh tay\n4. Nêm muối, đường vừa vặn',
  },
  {
    id: 8,
    name: 'Cà rốt luộc',
    ingredients: ['carrot'],
    instructions: '1. Gọt vỏ, cắt khúc cà rốt\n2. Luộc chín\n3. Vớt ra để nguội\n4. Chấm muối vừng',
  },
  {
    id: 9,
    name: 'Canh cà chua trứng',
    ingredients: ['tomato', 'egg'],
    instructions: '1. Cắt cà chua múi cau\n2. Đun nước sôi, cho cà chua vào\n3. Đập trứng vào, khuấy nhẹ\n4. Nêm nếm vừa ăn',
  },
  {
    id: 10,
    name: 'Thịt kho trứng',
    ingredients: ['meat', 'egg'],
    instructions: '1. Luộc trứng chín, bóc vỏ\n2. Thịt cắt miếng, ướp gia vị\n3. Kho thịt với nước dừa\n4. Cho trứng vào kho cùng',
  },
  {
    id: 11,
    name: 'Cá kho',
    ingredients: ['fish', 'onion'],
    instructions: '1. Ướp cá với gia vị\n2. Phi hành cho thơm\n3. Cho cá vào, đổ nước sôi vừa ngập\n4. Kho lửa nhỏ 20 phút',
  },
  {
    id: 12,
    name: 'Cá kho cà chua',
    ingredients: ['fish', 'tomato'],
    instructions: '1. Ướp cá với muối, tiêu\n2. Cắt cà chua múi cau\n3. Kho cá với cà chua\n4. Nấu đến khi sánh lại',
  },
  {
    id: 13,
    name: 'Thịt xào rau',
    ingredients: ['meat', 'vegetables'],
    instructions: '1. Thái thịt mỏng, ướp gia vị\n2. Xào thịt chín tới\n3. Cho rau vào xào nhanh\n4. Nêm nếm, đảo đều',
  },
  {
    id: 14,
    name: 'Đậu hũ sốt cà chua',
    ingredients: ['tofu', 'tomato'],
    instructions: '1. Chiên đậu hũ vàng\n2. Xào cà chua nhuyễn\n3. Cho đậu hũ vào đảo đều\n4. Nêm gia vị, nấu 5 phút',
  },
  {
    id: 15,
    name: 'Mì trứng',
    ingredients: ['noodles', 'egg'],
    instructions: '1. Luộc mì theo hướng dẫn\n2. Chiên trứng\n3. Cho mì ra tô, đặt trứng lên\n4. Rắc hành lá',
  },
  {
    id: 16,
    name: 'Mì xào rau',
    ingredients: ['noodles', 'vegetables'],
    instructions: '1. Luộc mì, để ráo\n2. Xào rau với tỏi\n3. Cho mì vào xào cùng\n4. Nêm nếm cho đậm đà',
  },
  {
    id: 17,
    name: 'Cơm chiên trứng',
    ingredients: ['rice', 'egg'],
    instructions: '1. Đánh trứng, chiên bông\n2. Cho cơm nguội vào xào\n3. Trộn đều với trứng\n4. Nêm nếm vừa ăn',
  },
  {
    id: 18,
    name: 'Khoai tây chiên',
    ingredients: ['potato'],
    instructions: '1. Gọt vỏ, thái que khoai tây\n2. Ngâm nước lạnh 10 phút\n3. Lau khô, chiên vàng giòn\n4. Rắc muối ớt',
  },
  {
    id: 19,
    name: 'Khoai tây nghiền',
    ingredients: ['potato'],
    instructions: '1. Luộc khoai tây chín\n2. Nghiền nhuyễn\n3. Trộn bơ, sữa\n4. Nêm muối tiêu',
  },
  {
    id: 20,
    name: 'Thịt xào bắp cải',
    ingredients: ['meat', 'cabbage'],
    instructions: '1. Thịt thái mỏng, ướp gia vị\n2. Thái bắp cải vừa phải\n3. Xào thịt chín, cho bắp cải vào\n4. Đảo đều, nêm nếm',
  },
  {
    id: 21,
    name: 'Canh cá rau',
    ingredients: ['fish', 'vegetables'],
    instructions: '1. Cá rửa sạch, cắt khúc\n2. Đun nước sôi\n3. Cho cá, rau vào nấu\n4. Nêm gia vị',
  },
  {
    id: 22,
    name: 'Canh thịt rau',
    ingredients: ['meat', 'vegetables'],
    instructions: '1. Thịt băm hoặc thái nhỏ\n2. Đun nước sôi\n3. Cho thịt, rau vào nấu\n4. Nêm nếm cho vừa ăn',
  },
  {
    id: 23,
    name: 'Đậu hũ kho cà chua',
    ingredients: ['tofu', 'tomato', 'onion'],
    instructions: '1. Chiên đậu hũ vàng\n2. Phi hành, cho cà chua vào xào\n3. Cho đậu hũ vào kho\n4. Nêm gia vị, nấu 10 phút',
  },
  {
    id: 24,
    name: 'Thịt kho khoai tây',
    ingredients: ['meat', 'potato'],
    instructions: '1. Thịt cắt miếng, ướp gia vị\n2. Khoai gọt vỏ, cắt múi\n3. Kho thịt với nước dừa\n4. Cho khoai vào kho cùng',
  },
  {
    id: 25,
    name: 'Mì xào thịt rau',
    ingredients: ['noodles', 'meat', 'vegetables'],
    instructions: '1. Luộc mì, để ráo\n2. Xào thịt chín\n3. Cho rau, mì vào xào đều\n4. Nêm gia vị đậm đà',
  },
  {
    id: 26,
    name: 'Cơm chiên thập cẩm',
    ingredients: ['rice', 'egg', 'vegetables', 'meat'],
    instructions: '1. Chiên trứng bông\n2. Xào thịt chín\n3. Cho cơm, rau vào xào đều\n4. Trộn trứng, nêm nếm',
  },
  {
    id: 27,
    name: 'Canh cà chua đậu hũ',
    ingredients: ['tomato', 'tofu'],
    instructions: '1. Cắt cà chua, đậu hũ\n2. Đun nước sôi\n3. Cho cà chua, đậu hũ vào\n4. Nêm nếm, nấu 5 phút',
  },
  {
    id: 28,
    name: 'Trứng xào cà chua',
    ingredients: ['egg', 'tomato'],
    instructions: '1. Đập trứng, đánh đều\n2. Cắt cà chua múi cau\n3. Xào cà chua mềm\n4. Đổ trứng vào, đảo đều',
  },
  {
    id: 29,
    name: 'Bắp cải luộc',
    ingredients: ['cabbage', 'carrot'],
    instructions: '1. Thái bắp cải, cà rốt\n2. Luộc chín\n3. Vớt ra, để ráo\n4. Chấm muối vừng hoặc tương',
  },
  {
    id: 30,
    name: 'Cá chiên sốt cà chua',
    ingredients: ['fish', 'tomato', 'onion'],
    instructions: '1. Chiên cá vàng\n2. Phi hành, xào cà chua\n3. Cho cá vào đảo nhẹ\n4. Nêm gia vị, nấu 5 phút',
  },
];

export default function IngredientSelector() {
  const [selected, setSelected] = useState<string[]>([]);
  const [suggestedRecipe, setSuggestedRecipe] = useState<typeof RECIPES[0] | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('selectedIngredients');
    if (saved) {
      setSelected(JSON.parse(saved));
    }
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' },
        audio: false 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
      }
    } catch (error) {
      console.error('Camera error:', error);
      alert('Không thể mở camera. Vui lòng cho phép truy cập camera.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const handleOpenCamera = () => {
    setShowCamera(true);
    setTimeout(() => startCamera(), 100);
  };

  const handleCloseCamera = () => {
    stopCamera();
    setShowCamera(false);
    setIsScanning(false);
  };

  const simulateDetection = () => {
    setIsScanning(true);
    
    setTimeout(() => {
      const availableIngredients = INGREDIENTS.filter(ing => !selected.includes(ing.id));
      const numToDetect = Math.min(Math.floor(Math.random() * 3) + 1, availableIngredients.length);
      const detectedIds: string[] = [];
      
      for (let i = 0; i < numToDetect; i++) {
        const randomIndex = Math.floor(Math.random() * availableIngredients.length);
        const detected = availableIngredients.splice(randomIndex, 1)[0];
        detectedIds.push(detected.id);
      }

      if (detectedIds.length > 0) {
        const newSelected = [...selected, ...detectedIds];
        setSelected(newSelected);
        localStorage.setItem('selectedIngredients', JSON.stringify(newSelected));
        
        const detectedNames = detectedIds.map(id => 
          INGREDIENTS.find(i => i.id === id)?.name
        ).join(', ');
        
        alert(`✅ Đã nhận dạng: ${detectedNames}`);
      }
      
      setIsScanning(false);
      handleCloseCamera();
    }, 2000);
  };

  const toggleIngredient = (id: string) => {
    const newSelected = selected.includes(id)
      ? selected.filter(i => i !== id)
      : [...selected, id];
    setSelected(newSelected);
    localStorage.setItem('selectedIngredients', JSON.stringify(newSelected));
    setSuggestedRecipe(null);
  };

  const suggestMeal = () => {
    const matchingRecipes = RECIPES.filter(recipe =>
      recipe.ingredients.every(ing => selected.includes(ing))
    );

    if (matchingRecipes.length > 0) {
      const randomRecipe = matchingRecipes[Math.floor(Math.random() * matchingRecipes.length)];
      setSuggestedRecipe(randomRecipe);
    } else {
      setSuggestedRecipe(null);
      alert('Chưa đủ nguyên liệu cho món nào. Hãy chọn thêm nguyên liệu!');
    }
  };

  const getNewSuggestion = () => {
    const matchingRecipes = RECIPES.filter(recipe =>
      recipe.ingredients.every(ing => selected.includes(ing)) &&
      recipe.id !== suggestedRecipe?.id
    );

    if (matchingRecipes.length > 0) {
      const randomRecipe = matchingRecipes[Math.floor(Math.random() * matchingRecipes.length)];
      setSuggestedRecipe(randomRecipe);
    } else {
      alert('Không còn món nào khác phù hợp!');
    }
  };

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <h3 className="font-semibold text-lg mb-4">Chọn nguyên liệu bạn đang có</h3>
        <div className="grid grid-cols-3 gap-2">
          {INGREDIENTS.map((ing) => (
            <Button
              key={ing.id}
              variant={selected.includes(ing.id) ? 'default' : 'outline'}
              onClick={() => toggleIngredient(ing.id)}
              className="h-auto py-3"
              data-testid={`button-ingredient-${ing.id}`}
            >
              {ing.name}
            </Button>
          ))}
        </div>
      </Card>

      <Button
        onClick={handleOpenCamera}
        variant="outline"
        className="w-full"
        size="lg"
        data-testid="button-scan-camera"
      >
        <Camera className="w-5 h-5 mr-2" />
        Scan nguyên liệu bằng camera
      </Button>

      {selected.length > 0 && (
        <Card className="p-4 bg-accent">
          <p className="text-sm text-muted-foreground mb-2">Đã chọn {selected.length} nguyên liệu:</p>
          <div className="flex flex-wrap gap-2">
            {selected.map(id => {
              const ing = INGREDIENTS.find(i => i.id === id);
              return (
                <Badge key={id} variant="secondary" data-testid={`badge-selected-${id}`}>
                  {ing?.name}
                </Badge>
              );
            })}
          </div>
        </Card>
      )}

      <Button
        onClick={suggestMeal}
        className="w-full"
        size="lg"
        disabled={selected.length === 0}
        data-testid="button-suggest-meal"
      >
        <ChefHat className="w-5 h-5 mr-2" />
        Gợi ý món ăn
      </Button>

      {suggestedRecipe && (
        <Card className="p-4" data-testid="card-suggested-recipe">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="font-bold text-xl text-primary">{suggestedRecipe.name}</h3>
              <div className="flex flex-wrap gap-1 mt-2">
                {suggestedRecipe.ingredients.map(ingId => {
                  const ing = INGREDIENTS.find(i => i.id === ingId);
                  return (
                    <Badge key={ingId} variant="outline" className="text-xs">
                      {ing?.name}
                    </Badge>
                  );
                })}
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={getNewSuggestion}
              data-testid="button-new-suggestion"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-sm">Cách nấu:</h4>
            <div className="text-sm text-foreground whitespace-pre-line bg-muted/50 p-3 rounded-md">
              {suggestedRecipe.instructions}
            </div>
          </div>
        </Card>
      )}

      <Dialog open={showCamera} onOpenChange={handleCloseCamera}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Scan nguyên liệu</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
                data-testid="video-camera"
              />
              {isScanning && (
                <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                  <div className="bg-background/90 px-4 py-2 rounded-lg">
                    <p className="text-sm font-medium">Đang nhận dạng...</p>
                  </div>
                </div>
              )}
            </div>
            
            <div className="text-center text-sm text-muted-foreground">
              <p>Hướng camera vào nguyên liệu của bạn</p>
              <p className="text-xs mt-1">(Demo: AI sẽ tự động nhận dạng nguyên liệu)</p>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={simulateDetection}
                disabled={isScanning}
                className="flex-1"
                size="lg"
                data-testid="button-capture"
              >
                <Camera className="w-5 h-5 mr-2" />
                {isScanning ? 'Đang scan...' : 'Chụp & Nhận dạng'}
              </Button>
              <Button
                onClick={handleCloseCamera}
                variant="outline"
                size="lg"
                data-testid="button-cancel-camera"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
