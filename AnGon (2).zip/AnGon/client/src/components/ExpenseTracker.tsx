import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { Trash2, Plus } from 'lucide-react';

interface Expense {
  id: string;
  amount: number;
  description: string;
  date: string;
}

type ViewMode = 'day' | 'week' | 'month';

export default function ExpenseTracker() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [viewMode, setViewMode] = useState<ViewMode>('day');

  useEffect(() => {
    const saved = localStorage.getItem('expenses');
    if (saved) {
      setExpenses(JSON.parse(saved));
    }
  }, []);

  const saveExpenses = (newExpenses: Expense[]) => {
    setExpenses(newExpenses);
    localStorage.setItem('expenses', JSON.stringify(newExpenses));
  };

  const addExpense = () => {
    if (amount && description) {
      const newExpense: Expense = {
        id: Date.now().toString(),
        amount: parseFloat(amount),
        description,
        date: new Date().toISOString(),
      };
      saveExpenses([newExpense, ...expenses]);
      setAmount('');
      setDescription('');
    }
  };

  const clearAll = () => {
    if (confirm('Bạn có chắc muốn xóa tất cả chi tiêu?')) {
      saveExpenses([]);
    }
  };

  const getFilteredExpenses = () => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    return expenses.filter(exp => {
      const expDate = new Date(exp.date);
      if (viewMode === 'day') {
        return expDate >= today;
      } else if (viewMode === 'week') {
        const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
        return expDate >= weekAgo;
      } else {
        const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
        return expDate >= monthAgo;
      }
    });
  };

  const filteredExpenses = getFilteredExpenses();
  const total = filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0);

  const chartData = filteredExpenses.slice(0, 7).map(exp => ({
    name: exp.description.substring(0, 10),
    value: exp.amount,
  }));

  const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <h3 className="font-semibold text-lg mb-4">Thêm chi tiêu mới</h3>
        <div className="space-y-3">
          <Input
            type="number"
            placeholder="Số tiền (VND)"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="text-lg"
            data-testid="input-expense-amount"
          />
          <Input
            type="text"
            placeholder="Mô tả (ví dụ: Ăn trưa)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            data-testid="input-expense-description"
          />
          <Button 
            onClick={addExpense} 
            className="w-full" 
            size="lg"
            data-testid="button-add-expense"
          >
            <Plus className="w-5 h-5 mr-2" />
            Thêm chi tiêu
          </Button>
        </div>
      </Card>

      <div className="flex gap-2">
        {(['day', 'week', 'month'] as ViewMode[]).map((mode) => (
          <Button
            key={mode}
            variant={viewMode === mode ? 'default' : 'outline'}
            onClick={() => setViewMode(mode)}
            className="flex-1"
            data-testid={`button-view-${mode}`}
          >
            {mode === 'day' ? 'Ngày' : mode === 'week' ? 'Tuần' : 'Tháng'}
          </Button>
        ))}
      </div>

      <Card className="p-6 bg-accent">
        <p className="text-sm text-muted-foreground mb-1">Tổng chi tiêu</p>
        <p className="text-3xl font-bold text-primary" data-testid="text-total-expense">
          {total.toLocaleString('vi-VN')} ₫
        </p>
      </Card>

      {chartData.length > 0 && (
        <Card className="p-4">
          <h3 className="font-semibold mb-4">Biểu đồ chi tiêu</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="hsl(var(--primary))"
                dataKey="value"
                label={(entry) => `${entry.value.toLocaleString()}₫`}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `${value.toLocaleString('vi-VN')} ₫`} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      )}

      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <h3 className="font-semibold">Danh sách chi tiêu</h3>
          {expenses.length > 0 && (
            <Button 
              variant="destructive" 
              size="sm" 
              onClick={clearAll}
              data-testid="button-clear-all"
            >
              <Trash2 className="w-4 h-4 mr-1" />
              Xóa tất cả
            </Button>
          )}
        </div>
        
        {filteredExpenses.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">Chưa có chi tiêu nào</p>
          </Card>
        ) : (
          <div className="space-y-2">
            {filteredExpenses.map((exp) => (
              <Card key={exp.id} className="p-4" data-testid={`card-expense-${exp.id}`}>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">{exp.description}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(exp.date).toLocaleDateString('vi-VN')}
                    </p>
                  </div>
                  <p className="font-semibold text-lg text-primary">
                    {exp.amount.toLocaleString('vi-VN')} ₫
                  </p>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
