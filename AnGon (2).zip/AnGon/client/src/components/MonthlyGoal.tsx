import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { AlertCircle, TrendingDown, Target, CheckCircle } from 'lucide-react';

interface Expense {
  id: string;
  amount: number;
  date: string;
}

export default function MonthlyGoal() {
  const [goal, setGoal] = useState<number>(0);
  const [goalInput, setGoalInput] = useState('');
  const [expenses, setExpenses] = useState<Expense[]>([]);

  useEffect(() => {
    const savedGoal = localStorage.getItem('monthlyGoal');
    if (savedGoal) {
      setGoal(parseFloat(savedGoal));
    }

    const savedExpenses = localStorage.getItem('expenses');
    if (savedExpenses) {
      setExpenses(JSON.parse(savedExpenses));
    }
  }, []);

  const saveGoal = () => {
    if (goalInput) {
      const newGoal = parseFloat(goalInput);
      setGoal(newGoal);
      localStorage.setItem('monthlyGoal', newGoal.toString());
      setGoalInput('');
    }
  };

  const getMonthlyExpenses = () => {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    
    return expenses.filter(exp => {
      const expDate = new Date(exp.date);
      return expDate >= firstDay;
    });
  };

  const monthlyExpenses = getMonthlyExpenses();
  const totalSpent = monthlyExpenses.reduce((sum, exp) => sum + exp.amount, 0);
  const percentage = goal > 0 ? Math.min((totalSpent / goal) * 100, 100) : 0;
  const isOverBudget = totalSpent > goal && goal > 0;
  const isNearLimit = percentage >= 80 && percentage < 100;

  const savingTips = [
    'Hãy thử nấu ăn tại nhà thay vì ăn ngoài',
    'Ưu tiên món ăn ít thịt, nhiều rau củ',
    'Mua nguyên liệu theo mùa sẽ rẻ hơn',
    'Lập kế hoạch bữa ăn trước để tránh lãng phí',
    'Mang theo hộp cơm thay vì mua suất ăn',
    'Giảm chi tiêu cho đồ uống, nước ngọt',
  ];

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <h3 className="font-semibold text-lg mb-4">Đặt mục tiêu chi tiêu tháng</h3>
        <div className="space-y-3">
          <Input
            type="number"
            placeholder="Nhập mục tiêu (VND)"
            value={goalInput}
            onChange={(e) => setGoalInput(e.target.value)}
            className="text-lg"
            data-testid="input-monthly-goal"
          />
          <Button 
            onClick={saveGoal} 
            className="w-full" 
            size="lg"
            data-testid="button-set-goal"
          >
            <Target className="w-5 h-5 mr-2" />
            Đặt mục tiêu
          </Button>
        </div>
      </Card>

      {goal > 0 && (
        <>
          <Card className="p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-muted-foreground">Đã chi trong tháng</p>
                  <p className="text-2xl font-bold text-primary" data-testid="text-spent-amount">
                    {totalSpent.toLocaleString('vi-VN')} ₫
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Mục tiêu</p>
                  <p className="text-2xl font-bold" data-testid="text-goal-amount">
                    {goal.toLocaleString('vi-VN')} ₫
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Progress value={percentage} className="h-3" />
                <p className="text-sm text-center text-muted-foreground" data-testid="text-percentage">
                  {percentage.toFixed(1)}% đã sử dụng
                </p>
              </div>

              {!isOverBudget && !isNearLimit && (
                <Card className="p-4 bg-green-50 border-green-200">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-green-900">Tuyệt vời!</p>
                      <p className="text-sm text-green-700">
                        Bạn đang quản lý chi tiêu tốt. Còn {(goal - totalSpent).toLocaleString('vi-VN')} ₫ trong tháng này.
                      </p>
                    </div>
                  </div>
                </Card>
              )}

              {isNearLimit && !isOverBudget && (
                <Card className="p-4 bg-orange-50 border-orange-200">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-orange-900">Cảnh báo!</p>
                      <p className="text-sm text-orange-700">
                        Bạn sắp đạt mức chi tiêu. Còn {(goal - totalSpent).toLocaleString('vi-VN')} ₫.
                      </p>
                    </div>
                  </div>
                </Card>
              )}

              {isOverBudget && (
                <Card className="p-4 bg-red-50 border-red-200" data-testid="card-over-budget">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-red-900">Bạn đã vượt quá mức chi tiêu dự kiến!</p>
                      <p className="text-sm text-red-700">
                        Vượt {(totalSpent - goal).toLocaleString('vi-VN')} ₫ so với mục tiêu.
                      </p>
                    </div>
                  </div>
                </Card>
              )}
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <TrendingDown className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Mẹo tiết kiệm</h3>
            </div>
            <div className="space-y-2">
              {savingTips.map((tip, index) => (
                <div key={index} className="flex gap-2" data-testid={`tip-${index}`}>
                  <span className="text-primary font-bold">•</span>
                  <p className="text-sm text-foreground">{tip}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 bg-accent">
            <h3 className="font-semibold mb-3">Tổng kết tháng</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Mục tiêu:</span>
                <span className="font-semibold">{goal.toLocaleString('vi-VN')} ₫</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Đã chi:</span>
                <span className="font-semibold text-primary">{totalSpent.toLocaleString('vi-VN')} ₫</span>
              </div>
              <div className="flex justify-between pt-2 border-t">
                <span className="font-semibold">
                  {isOverBudget ? 'Vượt mức:' : 'Còn lại:'}
                </span>
                <span className={`font-bold ${isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                  {Math.abs(goal - totalSpent).toLocaleString('vi-VN')} ₫
                </span>
              </div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
