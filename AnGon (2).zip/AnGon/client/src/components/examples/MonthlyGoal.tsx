import MonthlyGoal from '../MonthlyGoal';

export default function MonthlyGoalExample() {
  return <MonthlyGoal />;
}
