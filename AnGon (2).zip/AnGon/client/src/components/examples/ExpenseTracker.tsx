import ExpenseTracker from '../ExpenseTracker';

export default function ExpenseTrackerExample() {
  return <ExpenseTracker />;
}
