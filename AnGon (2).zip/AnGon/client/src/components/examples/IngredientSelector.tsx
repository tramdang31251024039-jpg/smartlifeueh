import IngredientSelector from '../IngredientSelector';

export default function IngredientSelectorExample() {
  return <IngredientSelector />;
}
