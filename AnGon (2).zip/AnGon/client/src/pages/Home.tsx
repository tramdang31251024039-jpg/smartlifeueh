import { useState } from 'react';
import ExpenseTracker from '@/components/ExpenseTracker';
import IngredientSelector from '@/components/IngredientSelector';
import MonthlyGoal from '@/components/MonthlyGoal';
import { Wallet, ChefHat, Target } from 'lucide-react';

type Tab = 'expense' | 'ingredient' | 'goal';

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>('expense');

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="sticky top-0 z-10 bg-primary text-primary-foreground shadow-sm">
        <div className="flex items-center justify-center h-16 px-4">
          <h1 className="text-2xl font-bold">Ăn Gọn</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-20">
        <div className="max-w-md mx-auto p-4">
          {activeTab === 'expense' && <ExpenseTracker />}
          {activeTab === 'ingredient' && <IngredientSelector />}
          {activeTab === 'goal' && <MonthlyGoal />}
        </div>
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-10">
        <div className="max-w-md mx-auto flex">
          <button
            onClick={() => setActiveTab('expense')}
            className={`flex-1 flex flex-col items-center gap-1 py-3 hover-elevate active-elevate-2 ${
              activeTab === 'expense' ? 'text-primary' : 'text-muted-foreground'
            }`}
            data-testid="tab-expense"
          >
            <Wallet className="w-6 h-6" />
            <span className="text-xs font-medium">Chi tiêu</span>
          </button>
          <button
            onClick={() => setActiveTab('ingredient')}
            className={`flex-1 flex flex-col items-center gap-1 py-3 hover-elevate active-elevate-2 ${
              activeTab === 'ingredient' ? 'text-primary' : 'text-muted-foreground'
            }`}
            data-testid="tab-ingredient"
          >
            <ChefHat className="w-6 h-6" />
            <span className="text-xs font-medium">Nguyên liệu</span>
          </button>
          <button
            onClick={() => setActiveTab('goal')}
            className={`flex-1 flex flex-col items-center gap-1 py-3 hover-elevate active-elevate-2 ${
              activeTab === 'goal' ? 'text-primary' : 'text-muted-foreground'
            }`}
            data-testid="tab-goal"
          >
            <Target className="w-6 h-6" />
            <span className="text-xs font-medium">Mục tiêu</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
