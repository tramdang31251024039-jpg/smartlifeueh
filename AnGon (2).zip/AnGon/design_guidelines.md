# Design Guidelines for "Ăn Gọn" - Vietnamese Student Budget App

## Design Approach
**Reference-Based Approach** - Drawing inspiration from popular Vietnamese finance/food apps and mobile-first utility apps like Zalo, Momo (Vietnam), and international references like Splitwise, Notion Mobile for clean data organization.

## Core Design Principles
- **Mobile-First Utility**: Optimized for portrait mobile screens (375px-428px primary viewport)
- **Touch-Friendly**: All interactive elements minimum 44x44px tap targets
- **Vietnamese Context**: Culturally appropriate iconography and comfortable reading for Vietnamese text

## Color Palette

**Light Mode (Primary):**
- Background: 0 0% 100% (pure white)
- Primary Blue: 200 85% 92% (pastel blue for cards/accents)
- Primary Action: 200 80% 55% (medium blue for buttons)
- Text Primary: 220 20% 20% (near-black for readability)
- Text Secondary: 220 15% 50% (gray for labels)
- Success: 145 60% 50% (green for under-budget)
- Warning: 35 90% 60% (orange for approaching limit)
- Danger: 0 75% 60% (red for over-budget)
- Border: 220 15% 88% (light gray dividers)

**Dark Mode Support**: Not required for MVP

## Typography
**Font System:**
- Primary: 'Inter', 'Noto Sans', sans-serif (excellent Vietnamese diacritics support)
- Fallback: system-ui, -apple-system

**Scale:**
- App Title: text-2xl font-bold (24px)
- Section Headers: text-xl font-semibold (20px)
- Card Titles: text-lg font-medium (18px)
- Body: text-base (16px)
- Labels/Meta: text-sm (14px)
- Caption: text-xs (12px)

## Layout System
**Spacing Primitives:** Consistent use of Tailwind units: 2, 4, 6, 8, 12, 16, 20

**Container Structure:**
- Full viewport height with fixed header (h-16) and bottom tab nav (h-16)
- Content area: flex-1 with overflow-y-auto
- Horizontal padding: px-4 (mobile), px-6 (tablet+)
- Section gaps: space-y-6 for major sections, space-y-4 for cards

**Grid Patterns:**
- Expense cards: Single column stack on mobile
- Chart area: Full width responsive container
- Ingredient grid: grid-cols-3 sm:grid-cols-4 for ingredient chips
- Meal cards: Single column with image-text layout

## Component Library

**Navigation:**
- Fixed Header: White background, shadow-sm, "Ăn Gọn" logo/title centered or left-aligned
- Bottom Tab Bar: 3 tabs (Chi Tiêu, Nguyên Liệu, Mục Tiêu) with icons, active state with blue background, fixed to bottom

**Buttons:**
- Primary: bg-blue-500 hover:bg-blue-600 text-white rounded-lg px-6 py-3 font-medium
- Secondary: bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg px-6 py-3
- Danger: bg-red-50 hover:bg-red-100 text-red-700 rounded-lg px-4 py-2

**Cards:**
- Expense Items: White background, rounded-xl, p-4, shadow-sm, border border-gray-100
- Meal Suggestion Cards: White background, rounded-xl, overflow-hidden, with image placeholder at top (aspect-video)
- Summary Cards: Pastel blue background (bg-blue-50), rounded-xl, p-6

**Forms:**
- Input Fields: border-2 border-gray-200 focus:border-blue-500 rounded-lg p-3, text-base
- Number Inputs: Larger text (text-lg) for expense amounts
- Checkboxes: Custom styled with blue accent, min 24x24px touch target

**Data Visualization:**
- Charts: Use Chart.js or Recharts with pastel blue color scheme
- Progress Bars: Rounded-full, blue fill with gradient (from-blue-400 to-blue-500)
- Stat Badges: Pill-shaped (rounded-full px-3 py-1) with colored backgrounds

**Icons:**
- Use Heroicons (outline style for inactive, solid for active states)
- Icon size: 24x24px for tabs, 20x20px for inline icons
- Color: text-gray-400 inactive, text-blue-600 active

**Alerts/Notifications:**
- Warning Toast: bg-orange-50 border-l-4 border-orange-500 p-4 rounded-r-lg
- Success Toast: bg-green-50 border-l-4 border-green-500 p-4 rounded-r-lg
- Danger Alert: bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg

## Feature-Specific Design

**Expense Tracking Section:**
- Quick add form at top (sticky below header)
- Time filter pills (Ngày/Tuần/Tháng) as horizontal scroll buttons
- Chart container: aspect-square with max-h-64 on mobile
- Expense list: Reverse chronological with date grouping headers

**Ingredient Scanner Section:**
- Category tabs (Protein/Veg/Grains) as horizontal scroll chips
- Ingredient grid with toggle buttons (checkbox style)
- Selected state: bg-blue-500 text-white transform scale-105
- "Gợi ý món ăn" button: Large, prominent, sticky to bottom of scroll area

**Monthly Goal Section:**
- Large progress circle or bar at top showing budget status
- Goal input: Prominent, currency formatted (VND)
- Comparison cards: side-by-side "Mục tiêu" vs "Đã chi"
- Tips list: bg-blue-50 rounded-lg p-4 space-y-2 with bullet points

## Animations
**Minimal, Purposeful Motion:**
- Tab transitions: Smooth slide (transition-transform duration-200)
- Card interactions: Subtle scale on tap (active:scale-98)
- Chart rendering: Fade-in with stagger (animate-fade-in delay-100/200/300)
- Toast notifications: Slide-in from top (animate-slide-down)

## Images
**No hero images required** - This is a utility app, not marketing.

**Functional Images:**
- Meal suggestion cards: Placeholder food images (aspect-video ratio, object-cover, rounded-t-xl)
- Empty states: Simple illustrated SVG graphics in blue accent color
- Icons: Heroicons for all UI elements

## Responsive Behavior
- Mobile-first: 375px-428px (primary)
- Tablet: 768px+ (optional wider layout, max-w-md centered)
- Desktop: Display mobile view centered with max-w-md, bg-gray-50 for visual containment